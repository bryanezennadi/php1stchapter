<?php
$discipline = [
    "informatica" => [
        "C:/Desktop/Informatica/primo" => ["argomento" => "programmazzione SQL", "mese" =>"settembre"],
        "C:/Desktop/Informatica/secondo" => ["argomento" => "programmazzione PHP", "mese" =>"novembre"]
    ],
    "TPSI" => [
        "C:/Desktop/TPSI/primo" => ["argomento" => "socket", "mese" =>"settembre"],
        "C:/Desktop/TPSI/secondo" => ["argomento" => "json", "mese" =>"novembre"]
    ],
    "sistemi" => [
        "C:/Desktop/Sistemi/primo" => ["argomento" => "Server Mail", "mese" =>"novembre"],
        "C:/Desktop/Sistemi/secondo" => ["argomento" => "Firewall", "mese" =>"dicembre"]
    ]
];
function getInfo(string $materia, string $percorso, array $materie): array|string {
    // Verifica se la materia esiste
    if (array_key_exists($materia, $materie)) {
        // Verifica se il percorso esiste per quella materia
        if (array_key_exists($percorso, $materie[$materia])) {
            $argomento = $materie[$materia][$percorso]["argomento"];
            $mese = $materie[$materia][$percorso]["mese"];
            return ["argomento" => $argomento, "mese" => $mese];
        } else {
            return "Percorso non trovato";
        }
    } else {
        return "Materia non trovata";
    }
}
$materia = "TPSI";
$percorso = "C:/Desktop/TPSI/primo";
$risultato = getInfo($materia, $percorso, $discipline);

if (is_array($risultato)) {
    echo "Materia: $materia\n";
    echo "Percorso: $percorso\n";
    echo "Argomento: " . $risultato["argomento"] . "\n";
    echo "Mese: " . $risultato["mese"] . "\n";
} else {
    echo $risultato . "\n";
}
?>